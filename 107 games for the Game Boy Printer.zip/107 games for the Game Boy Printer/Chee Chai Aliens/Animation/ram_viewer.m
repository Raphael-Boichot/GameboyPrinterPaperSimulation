%By Rapha�l BOICHOT, 1 june 2021

clc
clear
fid = fopen('Chee-Chai Alien (Japan).gbc','r');    
while ~feof(fid)
a=fread(fid);
end
fclose(fid);

ram=a;
frame=ram_decode(ram);
frame_png=(frame==3)*255+(frame==2)*125+(frame==1)*80+(frame==0)*0;
imwrite(uint8(frame_png),'Image_ram.png')
disp('Ram extracted')

